﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data.Entity;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Controls;

namespace SQLiteApp
{
    public class ApplicationViewModel : INotifyPropertyChanged
    {
        ApplicationContext db;
        ObservableCollection<Phone> phones;
        ObservableCollection<User> users;
        User connectUser;
        Phone selectedPhone;
        List<Phone> copyPhones;
        ObservableCollection<Phone> RemoveSearch = new ObservableCollection<Phone>(); 
        List<Phone> RemoveSlider;
        List<Phone> RemoveSerch = new List<Phone>();
        RelayCommand checkBoxSortCommand, sliderSortCommand, commandSearchButtom;
        public bool close;
        public bool tmp = true;

        public ObservableCollection<Phone> Phones
        {
            get { return phones; }
            set
            {
                phones = value;
                OnPropertyChanged("Phones");
            }
        }

        public List<Phone> CopyPhones
        {
            get { return copyPhones; }
            set
            {
                copyPhones = value;
                OnPropertyChanged("Phones");
            }
        }

        public ObservableCollection<User> Users
        {
            get { return users; }
            set
            {
                users = value;
                OnPropertyChanged("Users");
            }
        }

        public User ConnectUser
        {
            get { return connectUser; }
            set {
                connectUser = value;
                OnPropertyChanged("ConnectUser");
            }
        }

        public Phone SelectedPhone
        {
            get { return selectedPhone; }
            set
            {
                selectedPhone = value;
                OnPropertyChanged("ConnectUser");
            }
        }

        public ApplicationViewModel()
        {
            db = new ApplicationContext();

            db.Phones.Load();
            db.Phones.Local.ToBindingList();
            Phones = db.Phones.Local;

            db.Users.Load();
            db.Users.Local.ToBindingList();
            Users = db.Users.Local;

            OpenLoginWindow();
        }

        public void OpenLoginWindow()
        {
            LoginWindow loginWindow = new LoginWindow(users);
            close = false;
            if (loginWindow.ShowDialog() == false)
            {
                if (loginWindow.openRegistrationWindow)
                {
                    OpenRegistrationWindow();
                    return;
                }

                if (loginWindow.connectUser == null)
                {
                    close = true;
                }
                else
                {
                    ConnectUser = loginWindow.connectUser;
                }
            }
        }

        public void OpenRegistrationWindow()
        {
            RegistrationWindow registrationWindow = new RegistrationWindow();
            if(registrationWindow.ShowDialog() == false)
            {
                if (registrationWindow.openLoginWindow)
                {
                    OpenLoginWindow();
                    return;
                }

                if(registrationWindow.regUser == null)
                {
                    close = true;
                }
                else
                {    
                    ConnectUser = registrationWindow.regUser;
                    db.Users.Add(registrationWindow.regUser);
                    db.SaveChanges();
                }
            }
        }

        public void OpenDetailsWindow(object sender)
        {
            selectedPhone = sender as Phone;
            User SellerUser = new User();
            foreach (var u in Users)
            {
                if(u.Id == selectedPhone.Seller)
                {
                    SellerUser = u;
                }
            }

            DetailsWindow detailsWindow = new DetailsWindow(selectedPhone, SellerUser);
            if(detailsWindow.ShowDialog() == false)
            {

            }

        }

        public void OpenAddWindow()
        {
            AddWindow addWindow = new AddWindow();
            if(addWindow.ShowDialog() == false)
            {
                if(addWindow.addNewPhone == null)
                {
                    return;
                }
                else
                {
                    addWindow.addNewPhone.Seller = connectUser.Id;
                    db.Phones.Local.Add(addWindow.addNewPhone);
                    db.SaveChanges();
                }
            }
        }

        public RelayCommand Command
        {
            get
            {
                return checkBoxSortCommand ?? (checkBoxSortCommand = new RelayCommand((obj) =>
                {
                    CheckBox checkBox = obj as CheckBox;

                    if ((bool)checkBox.IsChecked && CopyPhones == null)
                    {
                        CopyPhones = Phones.Where(p => p.Company != checkBox.Content.ToString()).ToList();
                        foreach (var p in CopyPhones)
                        {
                            Phones.Remove(p);
                        }
                    }
                    else if ((bool)checkBox.IsChecked && CopyPhones != null)
                    {
                        foreach (var p in CopyPhones)
                        {
                            if(p.Company == checkBox.Content.ToString())
                            {
                                Phones.Add(p);
                            }
                        }
                        CopyPhones.RemoveAll(p => p.Company == checkBox.Content.ToString());
                    }
                    else
                    {
                        CopyPhones.AddRange(Phones.Where(p => p.Company == checkBox.Content.ToString()));
                        foreach (var p in CopyPhones)
                        {
                            if (p.Company == checkBox.Content.ToString())
                            {
                                Phones.Remove(p);
                            }
                        }

                        if (Phones.Count == 0)
                        {
                            foreach (var p in CopyPhones)
                            {
                                Phones.Add(p);
                            }

                            CopyPhones = null;
                        }
                    }
                }));
            }
        }

        public RelayCommand CommandSortSlider
        {
            get
            {
                return sliderSortCommand ?? (sliderSortCommand = new RelayCommand((value) =>
                {
                    UIElementCollection prices = (value as UIElementCollection);

                    RemoveSlider = new List<Phone>();
                    foreach (Phone p in phones)
                    {
                        if(Convert.ToInt32(prices[0].ToString().Remove(0, 33)) > p.Price)
                        {
                            RemoveSlider.Add(p);
                        }
                        else if(Convert.ToInt32(prices[2].ToString().Remove(0, 33)) < p.Price)
                        {
                            RemoveSlider.Add(p);
                        }
                    }

                    foreach (Phone p in RemoveSlider)
                    {
                        db.Phones.Local.Remove(p);
                    }
                }));
            }
        }

        public RelayCommand CommandSearchButtom
        {
            get
            {
                return commandSearchButtom ?? (commandSearchButtom = new RelayCommand((value) =>
                {
                    foreach (var n in RemoveSerch)
                    {
                        if(n != null)
                        {
                            Phones.Add(n);
                        }
                    }

                    foreach (var p in Phones)
                    {
                        if(p.Model != value.ToString())
                        {
                            RemoveSerch.Add(p);
                        }
                    }

                    foreach(var n in RemoveSerch)
                    {
                        Phones.Remove(n);
                    }
                }));
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        public void OnPropertyChanged([CallerMemberName]string prop = "")
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(prop));
        }
    }
}